// Sample student data
const students = [
    {
        id: 1,
        name: "Aarav Sharma",
        pin: "24T91A0566",
        branch: "CSE",
        section: "A",
        attendance: 92,
        photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
        email: "aarav.sharma@college.edu",
        phone: "+91 98765 43210",
        address: "123 Tech Street, Hyderabad",
        presentToday: true,
        attendanceHistory: [95, 88, 92, 90, 94, 87, 92, 89, 91, 93]
    },
    {
        id: 2,
        name: "Priya Patel",
        pin: "24T91A0567",
        branch: "CSE",
        section: "A",
        attendance: 88,
        photo: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
        email: "priya.patel@college.edu",
        phone: "+91 98765 43211",
        address: "456 Innovation Ave, Mumbai",
        presentToday: true,
        attendanceHistory: [92, 85, 88, 87, 90, 84, 88, 86, 89, 88]
    },
    {
        id: 3,
        name: "Rohit Kumar",
        pin: "24T91A0568",
        branch: "ECE",
        section: "B",
        attendance: 76,
        photo: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
        email: "rohit.kumar@college.edu",
        phone: "+91 98765 43212",
        address: "789 Circuit Lane, Delhi",
        presentToday: false,
        attendanceHistory: [80, 72, 76, 74, 78, 70, 76, 73, 77, 79]
    },
    {
        id: 4,
        name: "Ananya Singh",
        pin: "24T91A0569",
        branch: "CSE",
        section: "A",
        attendance: 94,
        photo: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
        email: "ananya.singh@college.edu",
        phone: "+91 98765 43213",
        address: "321 Code Boulevard, Bangalore",
        presentToday: true,
        attendanceHistory: [96, 92, 94, 93, 95, 91, 94, 92, 95, 97]
    },
    {
        id: 5,
        name: "Vikram Reddy",
        pin: "24T91A0570",
        branch: "EEE",
        section: "C",
        attendance: 82,
        photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face",
        email: "vikram.reddy@college.edu",
        phone: "+91 98765 43214",
        address: "654 Power Street, Chennai",
        presentToday: true,
        attendanceHistory: [85, 79, 82, 80, 84, 78, 82, 81, 83, 85]
    },
    {
        id: 6,
        name: "Sneha Gupta",
        pin: "24T91A0571",
        branch: "CSE",
        section: "B",
        attendance: 90,
        photo: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=150&h=150&fit=crop&crop=face",
        email: "sneha.gupta@college.edu",
        phone: "+91 98765 43215",
        address: "987 Algorithm Way, Pune",
        presentToday: true,
        attendanceHistory: [93, 87, 90, 88, 92, 86, 90, 89, 91, 93]
    },
    {
        id: 7,
        name: "Arjun Nair",
        pin: "24T91A0572",
        branch: "MECH",
        section: "A",
        attendance: 78,
        photo: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=150&h=150&fit=crop&crop=face",
        email: "arjun.nair@college.edu",
        phone: "+91 98765 43216",
        address: "147 Engineering Road, Kochi",
        presentToday: false,
        attendanceHistory: [82, 74, 78, 76, 80, 72, 78, 75, 79, 81]
    },
    {
        id: 8,
        name: "Kavya Iyer",
        pin: "24T91A0573",
        branch: "ECE",
        section: "A",
        attendance: 86,
        photo: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop&crop=face",
        email: "kavya.iyer@college.edu",
        phone: "+91 98765 43217",
        address: "258 Signal Street, Coimbatore",
        presentToday: true,
        attendanceHistory: [89, 83, 86, 84, 88, 82, 86, 85, 87, 89]
    },
    {
        id: 9,
        name: "Rahul Joshi",
        pin: "24T91A0574",
        branch: "CSE",
        section: "C",
        attendance: 74,
        photo: "https://images.unsplash.com/photo-1507591064344-4c6ce005b128?w=150&h=150&fit=crop&crop=face",
        email: "rahul.joshi@college.edu",
        phone: "+91 98765 43218",
        address: "369 Database Drive, Jaipur",
        presentToday: false,
        attendanceHistory: [78, 70, 74, 72, 76, 68, 74, 71, 75, 77]
    },
    {
        id: 10,
        name: "Meera Krishnan",
        pin: "24T91A0575",
        branch: "EEE",
        section: "B",
        attendance: 91,
        photo: "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=150&h=150&fit=crop&crop=face",
        email: "meera.krishnan@college.edu",
        phone: "+91 98765 43219",
        address: "741 Voltage Valley, Thiruvananthapuram",
        presentToday: true,
        attendanceHistory: [94, 88, 91, 89, 93, 87, 91, 90, 92, 94]
    }
];

// QR Codes mapping for demo
const qrCodes = {
    "STUDENT_566": 1,
    "STUDENT_567": 2,
    "STUDENT_568": 3,
    "STUDENT_569": 4,
    "STUDENT_570": 5,
    "STUDENT_571": 6,
    "STUDENT_572": 7,
    "STUDENT_573": 8,
    "STUDENT_574": 9,
    "STUDENT_575": 10
};

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Check authentication
    if (localStorage.getItem('isLoggedIn') !== 'true') {
        window.location.href = 'index.html';
        return;
    }

    // Set welcome message
    document.getElementById('welcomeUser').textContent = localStorage.getItem('username') || 'Admin';

    // Initialize components
    renderStudentTable();
    updateStats();
    initializeChart();
    setupEventListeners();
});

// Render student table
function renderStudentTable(filteredStudents = students) {
    const tbody = document.getElementById('studentTableBody');
    tbody.innerHTML = '';

    filteredStudents.forEach(student => {
        const row = document.createElement('tr');
        row.className = 'hover:bg-gray-50 cursor-pointer';
        
        const attendanceColor = student.attendance >= 85 ? 'text-green-600' : 
                               student.attendance >= 75 ? 'text-yellow-600' : 'text-red-600';
        
        const statusBadge = student.presentToday ? 
            '<span class="px-2 py-1 text-xs font-semibold bg-green-100 text-green-800 rounded-full">Present</span>' :
            '<span class="px-2 py-1 text-xs font-semibold bg-red-100 text-red-800 rounded-full">Absent</span>';

        row.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="flex items-center">
                    <img class="h-10 w-10 rounded-full object-cover" src="${student.photo}" alt="${student.name}">
                    <div class="ml-4">
                        <div class="text-sm font-medium text-gray-900">${student.name}</div>
                    </div>
                </div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900 font-mono">${student.pin}</div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <span class="px-2 py-1 text-xs font-semibold bg-blue-100 text-blue-800 rounded-full">${student.branch}</span>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${student.section}</td>
            <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm font-medium ${attendanceColor}">${student.attendance}%</div>
                <div class="w-full bg-gray-200 rounded-full h-2 mt-1">
                    <div class="bg-blue-600 h-2 rounded-full" style="width: ${student.attendance}%"></div>
                </div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">${statusBadge}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button onclick="showStudentProfile(${student.id})" class="text-indigo-600 hover:text-indigo-900">View Profile</button>
            </td>
        `;
        
        tbody.appendChild(row);
    });
}

// Update statistics
function updateStats() {
    const totalStudents = students.length;
    const presentToday = students.filter(s => s.presentToday).length;
    const absentToday = totalStudents - presentToday;
    const avgAttendance = Math.round(students.reduce((sum, s) => sum + s.attendance, 0) / totalStudents);

    document.getElementById('totalStudents').textContent = totalStudents;
    document.getElementById('presentToday').textContent = presentToday;
    document.getElementById('absentToday').textContent = absentToday;
    document.getElementById('avgAttendance').textContent = avgAttendance + '%';
}

// Initialize attendance chart
function initializeChart() {
    const ctx = document.getElementById('attendanceChart').getContext('2d');
    
    // Prepare data for chart
    const branchData = {};
    students.forEach(student => {
        if (!branchData[student.branch]) {
            branchData[student.branch] = [];
        }
        branchData[student.branch].push(student.attendance);
    });

    const labels = Object.keys(branchData);
    const avgAttendanceByBranch = labels.map(branch => {
        const attendances = branchData[branch];
        return Math.round(attendances.reduce((sum, att) => sum + att, 0) / attendances.length);
    });

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Average Attendance by Branch (%)',
                data: avgAttendanceByBranch,
                backgroundColor: [
                    'rgba(59, 130, 246, 0.8)',
                    'rgba(16, 185, 129, 0.8)',
                    'rgba(245, 158, 11, 0.8)',
                    'rgba(239, 68, 68, 0.8)'
                ],
                borderColor: [
                    'rgba(59, 130, 246, 1)',
                    'rgba(16, 185, 129, 1)',
                    'rgba(245, 158, 11, 1)',
                    'rgba(239, 68, 68, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y + '%';
                        }
                    }
                }
            }
        }
    });
}

// Setup event listeners
function setupEventListeners() {
    // Search functionality
    document.getElementById('searchInput').addEventListener('input', filterStudents);
    document.getElementById('branchFilter').addEventListener('change', filterStudents);
    
    // Scanner functionality
    document.getElementById('scanBtn').addEventListener('click', openScanner);
    document.getElementById('closeScannerBtn').addEventListener('click', closeScanner);
    
    // Side panel
    document.getElementById('closePanelBtn').addEventListener('click', closeSidePanel);
}

// Filter students
function filterStudents() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const branchFilter = document.getElementById('branchFilter').value;
    
    let filtered = students.filter(student => {
        const matchesSearch = student.name.toLowerCase().includes(searchTerm) || 
                             student.pin.toLowerCase().includes(searchTerm);
        const matchesBranch = !branchFilter || student.branch === branchFilter;
        
        return matchesSearch && matchesBranch;
    });
    
    renderStudentTable(filtered);
}

// Show student profile
function showStudentProfile(studentId) {
    const student = students.find(s => s.id === studentId);
    if (!student) return;

    const profileHTML = `
        <div class="text-center mb-6">
            <img src="${student.photo}" alt="${student.name}" class="w-24 h-24 rounded-full mx-auto mb-4 object-cover">
            <h3 class="text-xl font-bold text-gray-800">${student.name}</h3>
            <p class="text-gray-600">${student.pin}</p>
        </div>
        
        <div class="space-y-4">
            <div class="bg-gray-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800 mb-2">Academic Information</h4>
                <div class="space-y-2 text-sm">
                    <div class="flex justify-between">
                        <span class="text-gray-600">Branch:</span>
                        <span class="font-medium">${student.branch}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Section:</span>
                        <span class="font-medium">${student.section}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Overall Attendance:</span>
                        <span class="font-medium ${student.attendance >= 85 ? 'text-green-600' : student.attendance >= 75 ? 'text-yellow-600' : 'text-red-600'}">${student.attendance}%</span>
                    </div>
                </div>
            </div>
            
            <div class="bg-gray-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800 mb-2">Contact Information</h4>
                <div class="space-y-2 text-sm">
                    <div class="flex justify-between">
                        <span class="text-gray-600">Email:</span>
                        <span class="font-medium text-blue-600">${student.email}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Phone:</span>
                        <span class="font-medium">${student.phone}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Address:</span>
                        <span class="font-medium text-right ml-2">${student.address}</span>
                    </div>
                </div>
            </div>
            
            <div class="bg-gray-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800 mb-2">Today's Status</h4>
                <div class="text-center">
                    ${student.presentToday ? 
                        '<span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800"><i class="fas fa-check mr-2"></i>Present</span>' :
                        '<span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800"><i class="fas fa-times mr-2"></i>Absent</span>'
                    }
                </div>
            </div>
            
            <button onclick="markAttendance(${student.id})" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition duration-200">
                ${student.presentToday ? 'Mark as Absent' : 'Mark as Present'}
            </button>
        </div>
    `;

    document.getElementById('studentProfile').innerHTML = profileHTML;
    document.getElementById('sidePanel').classList.add('open');
}

// Close side panel
function closeSidePanel() {
    document.getElementById('sidePanel').classList.remove('open');
}

// Mark attendance
function markAttendance(studentId) {
    const student = students.find(s => s.id === studentId);
    if (student) {
        student.presentToday = !student.presentToday;
        renderStudentTable();
        updateStats();
        showStudentProfile(studentId); // Refresh the profile
        
        // Show notification
        showNotification(`${student.name} marked as ${student.presentToday ? 'Present' : 'Absent'}`, 
                        student.presentToday ? 'success' : 'info');
    }
}

// Scanner functionality
function openScanner() {
    document.getElementById('scannerOverlay').style.display = 'block';
    
    Quagga.init({
        inputStream: {
            name: "Live",
            type: "LiveStream",
            target: document.querySelector('#scanner'),
            constraints: {
                width: 600,
                height: 400,
                facingMode: "environment"
            }
        },
        decoder: {
            readers: ["code_128_reader", "ean_reader", "ean_8_reader", "code_39_reader", "code_39_vin_reader", "codabar_reader", "upc_reader", "upc_e_reader", "i2of5_reader"]
        }
    }, function(err) {
        if (err) {
            console.log(err);
            alert('Camera access denied or not available. Demo will use simulated scan.');
            simulateQRScan();
            return;
        }
        console.log("Initialization finished. Ready to start");
        Quagga.start();
    });

    // Listen for successful scans
    Quagga.onDetected(function(result) {
        const code = result.codeResult.code;
        processScannedCode(code);
        closeScanner();
    });
}

function closeScanner() {
    Quagga.stop();
    document.getElementById('scannerOverlay').style.display = 'none';
}

// Simulate QR scan for demo
function simulateQRScan() {
    setTimeout(() => {
        const randomCodes = Object.keys(qrCodes);
        const randomCode = randomCodes[Math.floor(Math.random() * randomCodes.length)];
        processScannedCode(randomCode);
        closeScanner();
    }, 2000);
}

// Process scanned code
function processScannedCode(code) {
    const studentId = qrCodes[code];
    if (studentId) {
        const student = students.find(s => s.id === studentId);
        if (student) {
            student.presentToday = true;
            renderStudentTable();
            updateStats();
            showNotification(`Attendance marked for ${student.name}`, 'success');
            showStudentProfile(studentId);
        }
    } else {
        showNotification('QR/Barcode not recognized', 'error');
    }
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 px-6 py-3 rounded-lg shadow-lg text-white transform translate-x-full transition-transform duration-300`;
    
    switch(type) {
        case 'success':
            notification.classList.add('bg-green-600');
            break;
        case 'error':
            notification.classList.add('bg-red-600');
            break;
        default:
            notification.classList.add('bg-blue-600');
    }
    
    notification.innerHTML = `
        <div class="flex items-center space-x-2">
            <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.classList.remove('translate-x-full');
    }, 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.classList.add('translate-x-full');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Logout function
function logout() {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('username');
    window.location.href = 'index.html';
}